USE TradingDB;
GO

CREATE TABLE TechnicalIndicators (
    IndicatorID INT IDENTITY(1,1) PRIMARY KEY,
    StockID INT FOREIGN KEY REFERENCES Stocks(StockID),
    Date DATE NOT NULL,
    RSI DECIMAL(10,2),
    MACD DECIMAL(10,2),
    BollingerMid DECIMAL(10,2),
    BollingerUpper DECIMAL(10,2),
    BollingerLower DECIMAL(10,2)
);

