CREATE DATABASE TradingDB;

USE TradingDB;
GO

CREATE TABLE Stocks (
    StockID INT IDENTITY(1,1) PRIMARY KEY,
    Ticker VARCHAR(10) NOT NULL,
    CompanyName VARCHAR(100),
    Sector VARCHAR(50)
);

CREATE TABLE StockPrices (
    PriceID INT IDENTITY(1,1) PRIMARY KEY,
    StockID INT FOREIGN KEY REFERENCES Stocks(StockID),
    Date DATE NOT NULL,
    OpenPrice DECIMAL(10,2),
    HighPrice DECIMAL(10,2),
    LowPrice DECIMAL(10,2),
    ClosePrice DECIMAL(10,2),
    Volume BIGINT
);

CREATE TABLE Benchmark (
    BenchID INT IDENTITY(1,1) PRIMARY KEY,
    IndexName VARCHAR(50),
    Date DATE NOT NULL,
    CloseValue DECIMAL(10,2)
);