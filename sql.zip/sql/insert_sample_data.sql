USE TradingDB;
GO

-- Insert stocks
INSERT INTO Stocks (Ticker, CompanyName, Sector) VALUES
    ('TCS', 'Tata Consultancy Services', 'IT'),
    ('RELIANCE', 'Reliance Industries', 'Conglomerate'),
    ('SBIN', 'State Bank of India', 'Banking'),
    ('INFY', 'Infosys', 'IT'),
    ('HDFCBANK', 'HDFC Bank', 'Banking');

-- Insert sample stock prices (for TCS, Jan 2025)
INSERT INTO StockPrices (StockID, Date, OpenPrice, HighPrice, LowPrice, ClosePrice, Volume) VALUES
    (1, '2025-01-01', 3800.00, 3850.00, 3750.00, 3825.50, 1200000),
    (1, '2025-01-02', 3825.50, 3870.00, 3800.00, 3850.25, 1300000);

-- Insert NIFTY 50 data
INSERT INTO Benchmark (IndexName, Date, CloseValue) VALUES
    ('NIFTY 50', '2025-01-01', 24000.00),
    ('NIFTY 50', '2025-01-0kvx2', 24150.75);
