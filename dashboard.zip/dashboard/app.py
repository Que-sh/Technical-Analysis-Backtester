from flask import Flask, render_template
import pandas as pd
import pyodbc
import matplotlib.pyplot as plt
import os

app = Flask(__name__)

# MSSQL connection
try:
    conn = pyodbc.connect(r'DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
except pyodbc.Error as e:
    print(f"Database connection failed: {e}")
    exit(1)

# Plot directory
plot_dir = r'C:\Users\shrad\OneDrive\Desktop\Projects\Technical-Analysis-Backtester\dashboard\static'
os.makedirs(plot_dir, exist_ok=True)

def generate_indicator_plot(ticker, stock_id):
    try:
        # Fetch data
        query = f"""
            SELECT sp.Date, sp.ClosePrice, ti.RSI, ti.MACD, ti.BollingerMid, ti.BollingerUpper, ti.BollingerLower
            FROM StockPrices sp
            JOIN TechnicalIndicators ti ON sp.StockID = ti.StockID AND sp.Date = ti.Date
            WHERE sp.StockID = {stock_id}
            ORDER BY sp.Date
        """
        df = pd.read_sql(query, conn, index_col='Date', parse_dates=['Date'])

        # Plot
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
        ax1.plot(df.index, df['ClosePrice'], label='Close Price', color='blue')
        ax1.plot(df.index, df['BollingerMid'], label='Bollinger Mid', color='black')
        ax1.plot(df.index, df['BollingerUpper'], label='Bollinger Upper', linestyle='--', color='gray')
        ax1.plot(df.index, df['BollingerLower'], label='Bollinger Lower', linestyle='--', color='gray')
        ax1.set_title(f'{ticker} Price and Bollinger Bands')
        ax1.legend()
        ax1.grid()

        ax2.plot(df.index, df['RSI'], label='RSI', color='purple')
        ax2.axhline(70, color='red', linestyle='--')
        ax2.axhline(30, color='green', linestyle='--')
        ax2.set_title('Relative Strength Index (RSI)')
        ax2.legend()
        ax2.grid()

        ax3.plot(df.index, df['MACD'], label='MACD', color='orange')
        ax3.set_title('MACD')
        ax3.legend()
        ax3.grid()

        plt.tight_layout()
        plot_path = os.path.join(plot_dir, f'{ticker}_indicators.png')
        plt.savefig(plot_path)
        plt.close()
    except Exception as e:
        print(f"Error generating plot for {ticker}: {e}")

# Generate plots for all stocks
try:
    cursor = conn.cursor()
    cursor.execute("SELECT StockID, Ticker FROM Stocks")
    stocks = cursor.fetchall()
    for stock in stocks:
        generate_indicator_plot(stock.Ticker, stock.StockID)
    cursor.close()
except pyodbc.Error as e:
    print(f"Database query failed: {e}")
    conn.close()
    exit(1)

@app.route('/<ticker>')
def dashboard(ticker):
    # Validate ticker
    valid_tickers = [stock.Ticker for stock in stocks]
    if ticker not in valid_tickers:
        return "Invalid ticker", 404
    return render_template('index.html', ticker=ticker)

if __name__ == '__main__':
    try:
        app.run(debug=True, port=5000)
    except OSError as e:
        print(f"Port 5000 in use. Try another port: {e}")
        app.run(debug=True, port=5001)
    finally:
        conn.close()