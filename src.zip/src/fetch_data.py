import yfinance as yf
import pandas as pd
import pyodbc
import os
from datetime import datetime

# Create src directory if it doesn't exist
output_dir = 'C:\\Users\\shrad\\OneDrive\\Desktop\\Projects\\Technical-Analysis-Backtester\\src'
os.makedirs(output_dir, exist_ok=True)

# Connect to MSSQL
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()

# Define tickers
stocks = ['TCS.NS', 'RELIANCE.NS', 'SBIN.NS', 'INFY.NS', 'HDFCBANK.NS']
index = '^NSEI'

# Fetch stock data
start_date = '2024-01-01'
end_date = '2025-05-29'
stock_data = {}
for ticker in stocks:
    stock = yf.Ticker(ticker)
    df = stock.history(start=start_date, end=end_date, interval='1d')
    stock_data[ticker.replace('.NS', '')] = df

# Fetch NIFTY 50 data
nifty = yf.Ticker(index)
nifty_data = nifty.history(start=start_date, end=end_date, interval='1d')

# Save to CSV for inspection
for ticker, df in stock_data.items():
    df.to_csv(f'{output_dir}\\{ticker}_prices.csv')
nifty_data.to_csv(f'{output_dir}\\nifty50_prices.csv')

# Insert stock prices
cursor.execute("SELECT StockID, Ticker FROM Stocks")
stock_ids = {row.Ticker: row.StockID for row in cursor.fetchall()}
for ticker, df in stock_data.items():
    stock_id = stock_ids.get(ticker)
    if stock_id:
        for date, row in df.iterrows():
            cursor.execute("""
                INSERT INTO StockPrices (StockID, Date, OpenPrice, HighPrice, LowPrice, ClosePrice, Volume)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                stock_id,
                date.strftime('%Y-%m-%d'),
                round(row['Open'], 2),
                round(row['High'], 2),
                round(row['Low'], 2),
                round(row['Close'], 2),
                int(row['Volume'])
            ))

# Insert NIFTY 50 data
for date, row in nifty_data.iterrows():
    cursor.execute("""
        INSERT INTO Benchmark (IndexName, Date, CloseValue)
        VALUES (?, ?, ?)
    """, ('NIFTY 50', date.strftime('%Y-%m-%d'), round(row['Close'], 2)))

# Commit and close
conn.commit()
conn.close()

print(f"Inserted data for {len(stock_data)} stocks and NIFTY 50 into TradingDB.")