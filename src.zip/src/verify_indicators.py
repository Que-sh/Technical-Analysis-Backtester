import pyodbc
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()
cursor.execute("SELECT TOP 5 StockID, Date, RSI, MACD, BollingerMid FROM TechnicalIndicators WHERE StockID = 1")
print("TCS Technical Indicators:")
for row in cursor.fetchall():
    print(row)
conn.close()