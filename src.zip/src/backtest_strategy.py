import pandas as pd
import pyodbc
import matplotlib.pyplot as plt

# Connect to MSSQL
conn = pyodbc.connect(r'DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()

# Initialize portfolio
initial_capital = 100000  # Per stock
portfolio = {}

# Fetch stock data
cursor.execute("SELECT StockID, Ticker FROM Stocks")
stocks = cursor.fetchall()
for stock in stocks:
    stock_id, ticker = stock.StockID, stock.Ticker
    query = f"""
        SELECT sp.Date, sp.ClosePrice, ti.RSI
        FROM StockPrices sp
        JOIN TechnicalIndicators ti ON sp.StockID = ti.StockID AND sp.Date = ti.Date
        WHERE sp.StockID = {stock_id}
        ORDER BY sp.Date
    """
    df = pd.read_sql(query, conn, index_col='Date', parse_dates=['Date'])

    # Generate trading signals
    signals = []
    for i in range(1, len(df)):
        if df['RSI'].iloc[i] < 30 and df['RSI'].iloc[i-1] >= 30:
            signals.append('BUY')
        elif df['RSI'].iloc[i] > 70 and df['RSI'].iloc[i-1] <= 70:
            signals.append('SELL')
        else:
            signals.append('HOLD')
    df['Signal'] = [None] + signals

    # Backtest
    cash = initial_capital
    holdings = 0
    portfolio_values = []
    for date, row in df.iterrows():
        price = row['ClosePrice']
        if row['Signal'] == 'BUY' and cash > 0:
            holdings = cash // price
            cash -= holdings * price
        elif row['Signal'] == 'SELL' and holdings > 0:
            cash += holdings * price
            holdings = 0
        portfolio_value = cash + holdings * price
        portfolio_values.append(portfolio_value)
    df['PortfolioValue'] = portfolio_values

    portfolio[ticker] = df
    print(f"Backtested {ticker}: Final Portfolio Value = ₹{portfolio_values[-1]:.2f}")

# Fetch NIFTY 50 for comparison
nifty_df = pd.read_sql("SELECT Date, CloseValue FROM Benchmark WHERE IndexName = 'NIFTY 50' ORDER BY Date", conn, index_col='Date', parse_dates=['Date'])
nifty_returns = (nifty_df['CloseValue'] / nifty_df['CloseValue'].iloc[0] - 1) * 100

# Plot portfolio vs. NIFTY 50
plt.figure(figsize=(10, 6))
for ticker, df in portfolio.items():
    returns = (df['PortfolioValue'] / initial_capital - 1) * 100
    plt.plot(df.index, returns, label=f'{ticker} Strategy')
plt.plot(nifty_returns.index, nifty_returns, label='NIFTY 50', linestyle='--')
plt.xlabel('Date')
plt.ylabel('Returns (%)')
plt.title('RSI Strategy Returns vs. NIFTY 50')
plt.legend()
plt.grid()
plt.savefig('C:\\Users\\shrad\\OneDrive\\Desktop\\Projects\\Technical-Analysis-Backtester\\src\\strategy_returns.png')
plt.close()

# Commit and close
conn.close()