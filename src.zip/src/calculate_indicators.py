import pandas as pd
import pyodbc
from ta.momentum import RSIIndicator
from ta.trend import MACD
from ta.volatility import BollingerBands

# Connect to MSSQL
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()

# Fetch stock data
cursor.execute("SELECT StockID, Ticker FROM Stocks")
stocks = cursor.fetchall()
for stock in stocks:
    stock_id, ticker = stock.StockID, stock.Ticker
    query = f"SELECT Date, ClosePrice FROM StockPrices WHERE StockID = {stock_id} ORDER BY Date"
    df = pd.read_sql(query, conn, index_col='Date', parse_dates=['Date'])

    # Calculate indicators
    rsi = RSIIndicator(df['ClosePrice'], window=14).rsi()
    macd = MACD(df['ClosePrice']).macd()
    bb = BollingerBands(df['ClosePrice'], window=20)
    bb_mid = bb.bollinger_mavg()
    bb_upper = bb.bollinger_hband()
    bb_lower = bb.bollinger_lband()

    # Combine indicators into DataFrame
    indicators = pd.DataFrame({
        'RSI': rsi,
        'MACD': macd,
        'BollingerMid': bb_mid,
        'BollingerUpper': bb_upper,
        'BollingerLower': bb_lower
    }).dropna()

    # Insert into TechnicalIndicators
    for date, row in indicators.iterrows():
        cursor.execute("""
            INSERT INTO TechnicalIndicators (StockID, Date, RSI, MACD, BollingerMid, BollingerUpper, BollingerLower)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            stock_id,
            date.strftime('%Y-%m-%d'),
            round(row['RSI'], 2),
            round(row['MACD'], 2),
            round(row['BollingerMid'], 2),
            round(row['BollingerUpper'], 2),
            round(row['BollingerLower'], 2)
        ))

    print(f"Calculated and inserted indicators for {ticker}")

# Commit and close
conn.commit()
conn.close()