import pyodbc

conn = pyodbc.connect('DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()
cursor.execute("SELECT * FROM Stocks")
for row in cursor.fetchall():
    print(row)
conn.close()