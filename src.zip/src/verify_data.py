import pyodbc
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=.\SQLEXPRESS;DATABASE=TradingDB;Trusted_Connection=yes;')
cursor = conn.cursor()
cursor.execute("SELECT TOP 5 * FROM StockPrices WHERE StockID = 1")
print("TCS Stock Prices:")
for row in cursor.fetchall():
    print(row)
cursor.execute("SELECT TOP 5 * FROM Benchmark WHERE IndexName = 'NIFTY 50'")
print("\nNIFTY 50 Benchmark:")
for row in cursor.fetchall():
    print(row)
conn.close()